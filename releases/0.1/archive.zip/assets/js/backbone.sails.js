(function() {
  var __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  (function(Backbone, $, _) {
    var FakeCollection, FakeModel, Sails, associationError, attemptRequest, augmentUrl, clientFound, clientNotFoundError, configure, getConfig, getHeader, getModelName, idError, isCollection, isModel, isModelConstructor, keys, mapConfig, methodMap, modelNameError, parseConfig, parseQuery, promise, queryString, register, sendSocketRequest, sendingAjaxRequest, sendingSocketRequest, socketClient, socketConnected, socketConnecting, timeoutError, urlError, wrapError, wrapPayload;
    socketClient = void 0;
    Sails = {};
    Sails.Models = {};
    Sails.config = {
      eventPrefix: "",
      populate: false,
      where: false,
      limit: 30,
      sort: false,
      skip: false,
      watch: true,
      prefix: '',
      sync: ['socket', 'ajax', 'subscribe'],
      timeout: false,
      poll: 50,
      client: function() {
        return io.socket;
      },
      promise: function(promise) {
        return promise;
      },
      log: true,
      state: 'client'
    };
    keys = {
      modelConfig: ['populate', 'sync'],
      modelQuery: ['populate'],
      collectionConfig: ['populate', 'sync', 'where', 'sort', 'skip', 'limit', 'watch'],
      collectionQuery: ['populate', 'where', 'sort', 'skip', 'limit', 'watch'],
      messageAction: '__action',
      configPrefix: '__config'
    };
    Sails.configure = function(key, config) {
      var conf;
      if (_.isObject(key)) {
        return mapConfig(key);
      } else {
        (conf = {})[key] = config;
        return mapConfig(conf);
      }
    };
    mapConfig = function(config) {
      var key, val;
      for (key in config) {
        val = config[key];
        if (parseConfig[key] != null) {
          Sails.config[key] = parseConfig[key](val);
        } else {
          Sails.config[key] = val;
        }
      }
      return Sails.config;
    };
    parseConfig = {
      eventPrefix: function(prefix) {
        if (_.isString(prefix)) {
          if (prefix.length && _.last(prefix) !== ':') {
            prefix += ':';
          }
          return prefix;
        } else if (!prefix) {
          return '';
        } else {
          throw new Error("config.eventPrefix should be a string");
        }
      },
      prefix: function(prefix) {
        if (_.isString(prefix)) {
          if (prefix.length && prefix[0] !== '/') {
            prefix = '/' + prefix;
          }
          return prefix;
        } else if (!prefix) {
          return '';
        } else {
          throw new Error("config.prefix should be a string");
        }
      }
    };
    getConfig = function(key, options, instance) {
      var _ref;
      if (options[key] != null) {
        return options[key];
      } else if (instance[keys.configPrefix + key] != null) {
        return instance[keys.configPrefix + key];
      } else if (((_ref = instance.config) != null ? _ref[key] : void 0) != null) {
        return instance.config[key];
      } else {
        return Sails.config[key];
      }
    };
    modelNameError = function() {
      throw new Error("A `modelName` is required");
    };
    urlError = function() {
      throw new Error('A `url` property or function must be specified');
    };
    idError = function() {
      throw new Error('An `id` property must be specified');
    };
    clientNotFoundError = function() {
      throw new Error('A socket client could not be found. Consider revising `Sails.config.client`');
    };
    timeoutError = function(time) {
      throw new Error("Timed out after " + time + "ms");
    };
    associationError = function(key) {
      throw new Error("No association found with key " + key);
    };
    promise = {
      chain: function(from, to) {
        from.then(function() {
          return to.resolve.apply(to, arguments);
        });
        return from.fail(function() {
          return to.reject.apply(to, arguments);
        });
      },
      timeout: function(defer) {
        var timeout, to;
        timeout = Sails.config.timeout;
        if (timeout !== false) {
          to = setTimeout(function() {
            return defer.reject(timeout);
          }, timeout);
          defer.always(function() {
            return clearTimeout(to);
          });
        }
        return defer;
      },
      pollFor: function(boolF, polling) {
        if (polling) {
          if (boolF()) {
            boolF.polling = false;
            return boolF.defer.resolve();
          } else {
            setTimeout(function() {
              return promise.pollFor(boolF, true);
            }, Sails.config.poll);
            return boolF.defer;
          }
        } else if (boolF.polling) {
          return boolF.defer;
        } else {
          boolF.defer = $.Deferred();
          boolF.polling = true;
          return promise.pollFor(boolF, true);
        }
      },
      wrap: function(promise, internal) {
        if (internal) {
          return promise;
        } else {
          return Sails.config.promise(promise);
        }
      }
    };
    isModel = function(instance) {
      return instance instanceof Backbone.Model;
    };
    isCollection = function(instance) {
      return instance instanceof Backbone.Collection;
    };
    isModelConstructor = function(ctor) {
      return ctor.prototype instanceof Backbone.Model || ctor === Backbone.Model;
    };
    getModelName = function(instance) {
      return _.result(instance, 'modelName').toLowerCase();
    };
    getHeader = function(xhr, header) {
      if (xhr.headers != null) {
        return xhr.headers[header];
      } else {
        return xhr.getResponseHeader(header);
      }
    };
    clientFound = function() {
      return Sails.config.client().socket != null;
    };
    promise.pollFor(clientFound).done(function() {
      return socketClient = Sails.config.client();
    });
    setTimeout(function() {
      if (!clientFound()) {
        return clientNotFoundError();
      }
    }, 5000);
    socketConnected = function() {
      var _ref;
      return socketClient != null ? (_ref = socketClient.socket) != null ? _ref.connected : void 0 : void 0;
    };
    Sails.connected = function() {
      return Boolean(socketConnected());
    };
    socketConnecting = function() {
      return promise.timeout(promise.pollFor(socketConnected)).fail(timeoutError).promise();
    };
    Sails.connecting = function() {
      return promise.wrap(socketConnecting());
    };
    methodMap = {
      create: 'post',
      read: 'get',
      update: 'put',
      patch: 'put',
      "delete": 'delete'
    };
    sendSocketRequest = function(method, instance, options) {
      var defer, handler, payload, url, _ref;
      defer = new $.Deferred();
      url = options.url || _.result(instance, 'url') || urlError;
      method = ((_ref = options.method) != null ? _ref.toLowerCase() : void 0) || methodMap[method];
      payload = options.payload ? options.payload : isCollection(instance) ? void 0 : payload = instance.attributes;
      handler = function(res, jwres) {
        if (Sails.config.log) {
          console.info("socket response:", jwres.statusCode, jwres.body, jwres.headers);
        }
        if (jwres.statusCode >= 400) {
          if (typeof options.error === "function") {
            options.error(jwres, jwres.statusCode, jwres.body);
          }
          defer.reject(jwres, jwres.statusCode, jwres.body);
        } else {
          if (typeof options.success === "function") {
            options.success(res, jwres.statusCode, jwres);
          }
          defer.resolve(res, jwres.statusCode, jwres);
        }
        return instance.trigger("request", instance, promise.wrap(defer.promise()), options);
      };
      if (Sails.config.log) {
        console.info("socket request:", method, url, payload);
      }
      if (payload) {
        socketClient[method](url, payload, handler);
      } else {
        socketClient[method](url, handler);
      }
      return defer.promise();
    };
    sendingSocketRequest = function(method, instance, options) {
      var result;
      result = $.Deferred();
      socketConnecting().done(function() {
        augmentUrl(method, instance, options);
        return promise.chain(sendSocketRequest(method, instance, options), result);
      }).fail(function(timeout) {
        return result.reject(timeout, method, instance, options);
      });
      return result;
    };
    sendingAjaxRequest = function(method, instance, options) {
      var result;
      augmentUrl(method, instance, options);
      result = instance.sync(method, instance, options);
      return result;
    };
    augmentUrl = function(method, instance, options) {
      var url;
      url = options.url || _.result(instance, 'url');
      if (isCollection(instance)) {
        url += queryString(instance, options, keys.collectionQuery);
      } else if (method !== 'delete') {
        url += queryString(instance, options, keys.modelQuery);
      }
      return options.url = url;
    };
    queryString = function(instance, options, keys) {
      var key, queries, query, _i, _len;
      queries = [];
      for (_i = 0, _len = keys.length; _i < _len; _i++) {
        key = keys[_i];
        query = getConfig(key, options, instance);
        if (query !== false) {
          queries.push("" + key + "=" + (parseQuery[key](query)));
        }
      }
      if (queries.length) {
        return '?' + queries.join('&');
      } else {
        return '';
      }
    };
    parseQuery = {
      where: function(criteria) {
        if (_.isObject(criteria)) {
          return JSON.stringify(criteria);
        } else {
          return criteria;
        }
      },
      sort: function(criteria) {
        if (_.isObject(criteria)) {
          return JSON.stringify(criteria);
        } else {
          return criteria;
        }
      },
      skip: function(criteria) {
        return criteria;
      },
      limit: function(criteria) {
        return criteria;
      },
      populate: function(criteria) {
        if (_.isObject(criteria || criteria === true)) {
          return JSON.stringify(criteria);
        } else if (criteria === 'true' || criteria === 'false') {
          return criteria;
        } else if (_.contains(criteria, ' ')) {
          return JSON.stringify(_.filter(criteria.split(' '), Boolean));
        } else {
          return criteria;
        }
      },
      watch: function(criteria) {
        if (criteria) {
          return 'true';
        } else {
          return 'false';
        }
      }
    };
    register = function(modelName, modelId) {
      if (!Sails.Models[modelName]) {
        Sails.Models[modelName] = _.extend({}, Backbone.Events);
        Sails.Models[modelName].handler = function(e) {
          if (e.verb === 'created') {
            return Sails.Models[modelName].trigger(e.verb, e);
          } else if (Sails.Models[modelName][e.id]) {
            return Sails.Models[modelName][e.id].trigger(e.verb, e);
          }
        };
        socketConnecting().done(function() {
          return socketClient.on(modelName, Sails.Models[modelName].handler);
        });
      }
      if (modelId != null) {
        if (!Sails.Models[modelName][modelId]) {
          return Sails.Models[modelName][modelId] = _.extend({}, Backbone.Events);
        }
      }
    };
    wrapError = function(instance, options) {
      var error;
      error = options.error;
      return options.error = function(resp, options) {
        if (options == null) {
          options = options;
        }
        if (error) {
          error(instance, resp, options);
        }
        return instance.trigger('error', instance, resp, options);
      };
    };
    wrapPayload = function(payload, options) {
      return _.assign(options, {
        contentType: 'application/json',
        data: JSON.stringify(payload),
        payload: _.cloneDeep(payload)
      });
    };
    attemptRequest = function(method, instance, options) {
      var ajaxSync, opts, populateConfig, result, set, socketSync, subscribe, sync;
      sync = getConfig('sync', options, instance);
      socketSync = _.contains(sync, 'socket');
      ajaxSync = _.contains(sync, 'ajax');
      subscribe = _.contains(sync, 'subscribe');
      set = _.contains(sync, 'set');
      opts = options;
      options = _.cloneDeep(opts);
      if (socketSync && socketConnected()) {
        options.sync = "socket";
        result = sendingSocketRequest(method, instance, options);
      } else if (ajaxSync || method === 'delete') {
        options.sync = "ajax";
        result = sendingAjaxRequest(method, instance, options);
        if (socketSync && method !== 'delete' && subscribe) {
          populateConfig = _.cloneDeep(getConfig('populate', options, instance));
          result.done(function() {
            var idAttr, ids;
            options = _.cloneDeep(opts);
            options.method = 'GET';
            options.sync = "subscribe";
            if (set) {
              options.success = function(resp) {
                if (isModel(instance)) {
                  resp = instance.parse(resp, options);
                }
                if (!instance.set(resp, options)) {
                  return false;
                }
                return instance.trigger('sync', instance, resp, options);
              };
            } else {
              options.success = function() {};
            }
            options.error = _.partialRight(options.error, options);
            if (isCollection(instance)) {
              idAttr = instance.model.prototype.idAttribute;
              ids = _.pluck(instance.models, idAttr);
              options.sort = false;
              options.populate = populateConfig;
              options.skip = false;
              options.limit = false;
              (options.where = {})[idAttr] = ids;
            }
            return sendingSocketRequest(method, instance, options);
          });
        }
      } else {
        options.sync = "socket";
        result = sendingSocketRequest(method, instance, options);
      }
      return result;
    };
    configure = function(key, val) {
      var k, v;
      if (_.isString(key)) {
        this[keys.configPrefix + key] = val;
      } else {
        for (k in key) {
          v = key[k];
          this[keys.configPrefix + k] = v;
        }
      }
      return this;
    };
    Sails.Model = (function(_super) {
      __extends(Model, _super);

      Model.prototype.query = configure;

      Model.prototype.configure = configure;

      Model.prototype.populate = _.partial(configure, 'populate');

      Model.prototype.get = function(key, wrap) {
        var attr, _ref;
        if (wrap && (((_ref = this.assoc) != null ? _ref[key] : void 0) != null)) {
          attr = Model.__super__.get.apply(this, arguments);
          if (attr != null) {
            return new this.assoc[key](attr);
          } else {
            return attr;
          }
        } else {
          return Model.__super__.get.apply(this, arguments);
        }
      };

      Model.prototype.set = function(key, val, options) {
        var k, v;
        if (_.isObject(key)) {
          for (k in key) {
            v = key[k];
            if (isModel(v)) {
              key[k] = v.attributes;
            } else if (isCollection(v)) {
              key[k] = _.pluck(v.models, 'attributes');
            } else if (_.isFunction(v)) {
              key[k] = v(this.get(k));
            }
          }
        } else {
          if (isModel(val)) {
            val = val.attributes;
          } else if (isCollection(val)) {
            val = _.pluck(val.models, 'attributes');
          } else if (_.isFunction(val)) {
            val = val(this.get(key));
          }
        }
        return Model.__super__.set.call(this, key, val, options);
      };

      Model.prototype.message = function(action, data, options, internal) {
        var message;
        if (data == null) {
          data = {};
        }
        if (options == null) {
          options = {};
        }
        if (this.isNew()) {
          idError();
        }
        if (_.isObject(action)) {
          options = data;
          data = action;
        } else {
          data[keys.messageAction] = action;
        }
        options.url = "" + Sails.config.prefix + "/" + (getModelName(this)) + "/message/" + this.id;
        options.sync = ['socket', 'ajax'];
        message = new FakeModel(data);
        return promise.wrap(message.save({}, options), internal);
      };

      Model.prototype.addTo = function(key, model, options, internal) {
        var Model, id, payload, result;
        if (options == null) {
          options = {};
        }
        if (this.isNew()) {
          idError();
        }
        if (this.assoc[key] == null) {
          associationError(key);
        }
        if (isModelConstructor(this.assoc[key])) {
          throw new Error("Cannot `addTo` model associations, only collections.");
        }
        if (!isModel(model)) {
          Model = this.assoc[key].prototype.model;
          if (_.isString(model)) {
            id = model;
            model = new Model();
            model.set(model.idAttribute, id);
          } else if (_.isObject(model)) {
            model = new Model(model);
          } else {
            throw new Error("Parameter `model` invalid. Should be an object of attributes, a model instance or an id string.");
          }
        }
        if (model.isNew()) {
          payload = model.attributes;
          options.url = _.result(this, 'url') + ("/" + key);
        } else {
          payload = _.assign({}, model.attributes, {
            id: model.id
          });
          options.url = _.result(this, 'url') + ("/" + key + "/" + model.id);
        }
        options.method = 'POST';
        wrapPayload(payload, options);
        result = this.save({}, options, null, true);
        if (model.isNew()) {
          result.done(function(resp, status, xhr) {
            var json;
            json = getHeader(xhr, 'created');
            resp = JSON.parse(json);
            model.set(model.parse(resp, options));
            return model.trigger('sync', model, resp, options);
          });
        }
        return promise.wrap(result, internal);
      };

      Model.prototype.removeFrom = function(key, model, options, internal) {
        var Model, id, payload;
        if (options == null) {
          options = {};
        }
        if (this.isNew()) {
          idError();
        }
        if (this.assoc[key] == null) {
          associationError(key);
        }
        if (isModelConstructor(this.assoc[key])) {
          throw new Error("Cannot `removeFrom` model associations, only collections.");
        }
        if (!isModel(model)) {
          Model = this.assoc[key].prototype.model;
          if (_.isString(model)) {
            id = model;
            model = new Model();
            model.set(model.idAttribute, id);
          } else if (_.isObject(model)) {
            model = new Model(model);
          } else {
            throw new Error("Parameter `model` invalid. Should be an object of attributes, a model instance or an id string.");
          }
        }
        if (model.isNew()) {
          idError();
        }
        payload = _.assign({}, model.attributes, {
          id: model.id
        });
        wrapPayload(payload, options);
        options.method = 'DELETE';
        options.url = _.result(this, 'url') + ("/" + key + "/" + model.id);
        return promise.wrap(this.save({}, options, null, true), internal);
      };

      Model.prototype.destroy = function(options, internal) {
        var destroy, model, result, success;
        if (options) {
          options = _.cloneDeep(options);
        } else {
          options = {};
        }
        model = this;
        success = options.success;
        destroy = function() {
          return model.trigger('destroy', model, model.collection, options);
        };
        options.success = function(resp) {
          if (options.wait || model.isNew()) {
            destroy();
          }
          if (success) {
            success(model, resp, options);
          }
          if (!model.isNew()) {
            return model.trigger('sync', model, resp, options);
          }
        };
        if (this.isNew()) {
          options.success();
          return false;
        }
        wrapError(this, options);
        result = attemptRequest('delete', model, options);
        if (!options.wait) {
          destroy();
        }
        return promise.wrap(result, internal);
      };

      Model.prototype.save = function(key, val, options, internal) {
        var attributes, attrs, method, model, result, success;
        attributes = this.attributes;
        if ((key == null) || _.isObject(key)) {
          attrs = key;
          options = val;
        } else if (_.isString(key)) {
          (attrs = {})[key] = val;
        }
        options = _.extend({
          validate: true
        }, options);
        if (attrs && !options.wait) {
          if (!this.set(attrs, options)) {
            return false;
          }
        } else {
          if (!this._validate(attrs, options)) {
            return false;
          }
        }
        if (attrs && options.wait) {
          this.attributes = _.extend({}, attributes, attrs);
        }
        if (_.isUndefined(options.parse)) {
          options.parse = true;
        }
        model = this;
        success = options.success;
        options.success = function(resp) {
          var serverAttrs;
          model.attributes = attributes;
          serverAttrs = model.parse(resp, options);
          if (options.wait) {
            serverAttrs = _.extend(attrs || {}, serverAttrs);
          }
          if (_.isObject(serverAttrs) && !model.set(serverAttrs, options)) {
            return false;
          }
          if (typeof success === "function") {
            success(model, resp, options);
          }
          return model.trigger('sync', model, resp, options);
        };
        wrapError(this, options);
        method = this.isNew() ? 'create' : options.patch ? 'patch' : 'update';
        if (method === 'patch') {
          options.attrs = attrs;
        }
        result = attemptRequest(method, model, options);
        if (attrs && options.wait) {
          this.attributes = attributes;
        }
        return promise.wrap(result, internal);
      };

      Model.prototype.fetch = function(key, options, internal) {
        var defer, instance, model, opts, result, success;
        if (_.isString(key)) {
          if (this.assoc[key] == null) {
            return associationError(key);
          } else {
            defer = $.Deferred();
            instance = new this.assoc[key](this.get(key));
            opts = (options && _.cloneDeep(options)) || {};
            opts.populate = false;
            opts.url = this.url() + ("/" + key);
            if ((typeof instance.isNew === "function" ? instance.isNew() : void 0) === false) {
              opts.url += "/" + instance.id;
            }
            instance.fetch(opts, true).done(function(resp, status, xhr) {
              return defer.resolve(instance, resp, status, xhr);
            }).fail(function(xhr, status, resp) {
              return defer.reject(instance, xhr, status, resp);
            });
            return promise.wrap(defer, internal);
          }
        } else {
          options = key;
          internal = options;
          options = options ? _.cloneDeep(options) : {};
          if (!options.parse) {
            options.parse = true;
          }
          model = this;
          success = options.success;
          options.success = function(resp) {
            if (!model.set(model.parse(resp, options), options)) {
              return false;
            }
            if (success) {
              success(model, resp, options);
            }
            return model.trigger('sync', model, resp, options);
          };
          wrapError(this, options);
          result = attemptRequest('read', model, options);
          return promise.wrap(result, internal);
        }
      };

      Model.prototype.subscribe = function(options) {
        var aggregator, modelName, prefix, self;
        if (options == null) {
          options = {};
        }
        if (this.isNew()) {
          self = this;
          this.once("change:" + this.idAttribute, function() {
            return self.subscribe(options);
          });
          return false;
        }
        if (this.subscribed) {
          return true;
        }
        this.subscribed = true;
        modelName = getModelName(this);
        register(modelName, this.id);
        prefix = getConfig('eventPrefix', options, this);
        aggregator = Sails.Models[modelName][this.id];
        this.listenTo(aggregator, "addedTo", function(e) {
          this.trigger("" + prefix + "addedTo", this, e);
          return this.trigger("" + prefix + "addedTo:" + e.attribute, this, e.addedId, e);
        });
        this.listenTo(aggregator, "removedFrom", function(e) {
          this.trigger("" + prefix + "removedFrom", this, e);
          return this.trigger("" + prefix + "removedFrom:" + e.attribute, this, e.removedId, e);
        });
        this.listenTo(aggregator, "destroyed", function(e) {
          return this.trigger("" + prefix + "destroyed", this, e);
        });
        this.listenTo(aggregator, "updated", function(e) {
          var attribute, changed, val, _ref;
          changed = false;
          _ref = e.data;
          for (attribute in _ref) {
            val = _ref[attribute];
            if (this.get(attribute) !== val) {
              this.trigger("" + prefix + "updated:" + attribute, this, val, e);
              changed = true;
            }
          }
          if (changed) {
            return this.trigger("" + prefix + "updated", this, e);
          }
        });
        this.listenTo(aggregator, "messaged", function(e) {
          var action, data;
          data = _.cloneDeep(e.data);
          action = e.data[keys.messageAction];
          if (action == null) {
            return this.trigger("" + prefix + "messaged", this, data, e);
          } else {
            delete data[keys.messageAction];
            return this.trigger("" + prefix + action, this, data, e);
          }
        });
        return true;
      };

      function Model(attrs, options) {
        var key, val, _i, _len, _ref, _ref1, _ref2;
        Model.__super__.constructor.apply(this, arguments);
        if (this.modelName == null) {
          if ((this.modelName = (_ref = this.collection) != null ? _ref.modelName : void 0) == null) {
            modelNameError();
          }
        }
        this.urlRoot = function() {
          return "" + Sails.config.prefix + "/" + (getModelName(this));
        };
        this.subscribe(options);
        if (options != null) {
          _ref1 = keys.modelConfig;
          for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
            key = _ref1[_i];
            if (options[key] != null) {
              this[keys.configPrefix + key] = options[key];
            }
          }
        }
        if ((this.assoc != null) && !this.assoc.__parsed) {
          _ref2 = this.assoc;
          for (key in _ref2) {
            val = _ref2[key];
            if (_.isString(val)) {
              this.assoc[key] = Sails.Model.extend({
                modelName: val
              });
            } else if (_.isArray(val)) {
              this.assoc[key] = Sails.Collection.extend({
                modelName: val[0],
                model: Sails.Model.extend({
                  modelName: val[0]
                })
              });
            } else {
              if (this.assoc[key].length === 0) {
                this.assoc[key] = this.assoc[key]();
              }
            }
          }
          this.assoc.__parsed = true;
        }
      }

      return Model;

    })(Backbone.Model);
    FakeModel = (function(_super) {
      __extends(FakeModel, _super);

      function FakeModel() {
        return FakeModel.__super__.constructor.apply(this, arguments);
      }

      FakeModel.prototype.modelName = '__fake';

      return FakeModel;

    })(Sails.Model);
    Sails.Collection = (function(_super) {
      __extends(Collection, _super);

      Collection.prototype.query = configure;

      Collection.prototype.configure = configure;

      Collection.prototype.populate = _.partial(configure, 'populate');

      Collection.prototype.model = Sails.Model;

      Collection.prototype.message = function(namespace, data, options, internal) {
        var coll, idAttr, key, model, request, result, state, url, _i, _j, _k, _len, _len1, _len2, _ref, _ref1, _ref2, _ref3;
        coll = this;
        url = "" + Sails.config.prefix + "/" + (getModelName(this)) + "/message";
        if (_.isObject(namespace)) {
          options = data;
          data = namespace;
        } else {
          data[keys.messageAction] = namespace;
        }
        options.sync = ['socket', 'ajax'];
        options.url = url;
        wrapPayload(data, options);
        request = new FakeCollection();
        state = getConfig('state', options, coll);
        if (state === 'server') {
          _ref = keys.collectionQuery;
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            key = _ref[_i];
            options[key] = getConfig(key, options, this);
          }
        } else {
          _ref1 = keys.collectionQuery;
          for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
            key = _ref1[_j];
            options[key] = false;
          }
          options.where = {};
          idAttr = ((_ref2 = coll.at(0)) != null ? _ref2.idAttribute : void 0) || 'id';
          options.where[idAttr] = [];
          _ref3 = coll.models;
          for (_k = 0, _len2 = _ref3.length; _k < _len2; _k++) {
            model = _ref3[_k];
            if (!model.isNew()) {
              options.where[idAttr].push(model.id);
            } else if (Sails.config.log) {
              console.warn("Model has no `" + idAttr + "`, so will not be messaged.");
            }
          }
        }
        result = request.fetch(options, true);
        return promise.wrap(result, internal);
      };

      Collection.prototype.fetch = function(options, internal) {
        var collection, result, success;
        options = options ? _.cloneDeep(options) : {};
        if (options.parse == null) {
          options.parse = true;
        }
        success = options.success;
        collection = this;
        options.success = function(resp) {
          var method;
          method = options.reset ? 'reset' : 'set';
          collection[method](resp, options);
          if (success) {
            success(collection, resp, options);
          }
          return collection.trigger('sync', collection, resp, options);
        };
        wrapError(this, options);
        result = attemptRequest('read', collection, options);
        return promise.wrap(result, internal);
      };

      Collection.prototype.subscribe = function(options) {
        var aggregator, modelName, prefix;
        if (options == null) {
          options = {};
        }
        if (this.subscribed) {
          return;
        }
        this.subscribed = true;
        modelName = getModelName(this);
        register(modelName);
        prefix = getConfig('eventPrefix', options, this);
        aggregator = Sails.Models[modelName];
        return this.listenTo(aggregator, "created", function(e) {
          return this.trigger("" + prefix + "created", e.data, e);
        });
      };

      function Collection(models, options) {
        var key, model, modelName, _i, _len, _ref;
        if (this.modelName == null) {
          model = new this.model();
          if (modelName = model.modelName) {
            this.modelName = modelName;
          } else if ((models != null ? models.length : void 0) && (modelName = model[0].modelName)) {
            this.modelname = modelName;
          } else {
            modelNameError();
          }
        }
        this.url = function() {
          return "" + Sails.config.prefix + "/" + (getModelName(this));
        };
        this.subscribe(options);
        if (options != null) {
          _ref = keys.collectionConfig;
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            key = _ref[_i];
            if (options[key] != null) {
              this[keys.configPrefix + key] = options[key];
            }
          }
        }
        Collection.__super__.constructor.apply(this, arguments);
      }

      return Collection;

    })(Backbone.Collection);
    FakeCollection = (function(_super) {
      __extends(FakeCollection, _super);

      function FakeCollection() {
        return FakeCollection.__super__.constructor.apply(this, arguments);
      }

      FakeCollection.prototype.modelName = '__fake__';

      return FakeCollection;

    })(Sails.Collection);
    return Backbone.Sails = Sails;
  })(Backbone, $, _);

}).call(this);
